function [ vec ] = e2
%e2 returns the unit vector in the y-direction
%   outputs: e2 is the 3x1 vector [0 1 0]'
    
    vec = [0 1 0]';

end

